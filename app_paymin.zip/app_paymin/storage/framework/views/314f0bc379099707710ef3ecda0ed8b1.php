<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="assets/FEproject/src/output.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/FEproject/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/FEproject/src/components/report.css" />
    <link rel="shortcut icon" href="/assets/logoMin.png" type="image/x-icon">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <title>PayMin</title>

    <!-- Swiper -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <!-- Google Icons -->

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

    <!-- Style -->
    <style></style>
</head>

<body>
    <main class="flex items-center justify-between h-screen font-poppins box-border bg-[#E6EEFD]">
        <nav id="navbar" class="bg-white h-full overflow-hidden w-[7.2rem] min-w-[7.2rem] p-5 shadow-4xl rounded-r-4xl">
            <div class="flex items-center justify-center mb-2">
                <img src="/assets/logoMin.png" alt="Logo" class="w-20 h-w-20 rounded-full" />
            </div>
            <ul id="navbar-list" class="flex flex-col h-full w-full relative z-10">
                <!-- Daftar item navigasi utama -->

                <li
                    class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-white transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer">
                    <a href="" class="flex flex-col items-center justify-center" onclick="route()">
                        <i class="fa fa-home fa-2x"></i>
                        <p class="text-sm">Home</p>
                    </a>
                </li>
                <li
                    class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-white transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer">
                    <a href="<?php echo e(route('Order')); ?>" class="flex flex-col items-center justify-center" onclick="route()">
                        <i class="fa fa-cart-plus fa-2x"></i>
                        <p class="text-sm">Orders</p>
                    </a>
                </li>
                <li
                    class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-white transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer">
                    <a href="<?php echo e(route('Report')); ?>" class="flex flex-col items-center justify-center" onclick="route()">
                        <i class="fa fa-file-text-o fa-2x"></i>
                        <p class="text-sm">Report</p>
                    </a>
                </li>
                <li
                    class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-white transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer">
                    <a href="" class="flex flex-col items-center justify-center" onclick="route()">
                        <i class="fa fa-th fa-2x"></i>
                        <p class="text-sm">Items</p>
                    </a>
                </li>
                <li
                    class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-white transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer active">
                    <a href="<?php echo e(route('Master')); ?>" class="flex flex-col items-center justify-center" onclick="route()">
                        <i class="fa fa-key fa-2x"></i>
                        <p class="text-sm">Master</p>
                    </a>
                </li>
                <li
                    class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-white transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer">
                    <a href="<?php echo e(route('Setting')); ?>" class="flex flex-col items-center justify-center"
                        onclick="route()">
                        <i class="fa fa-cog fa-2x"></i>
                        <p class="text-sm">Settings</p>
                    </a>
                </li>
                <span class="highlight-span mx-auto shadow-2xl"></span>
                <li
                    class="flex flex-col items-center justify-center mt-[4em] text-[#8B8B8B] hover:text-red-400 cursor-pointer">
                    <a href="<?php echo e(route('logout')); ?>" class="flex flex-col items-center justify-center" onclick="route()">
                        <i class="fa fa-sign-out fa-2x"></i>
                        <p class="text-sm">Logout</p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- Main Content -->
        <section class="h-full w-full p-11 box-border overflow-y-auto">
            <div class="mb-8">
                <h1 class="text-[36pt] font-bold text-[#353535]">
                    Orders History
                </h1>
            </div>

            <div class="flex gap-4 py-6 w-full">
                <!-- Card 1 -->
                <div class="bg-white rounded-lg shadow-4xl w-full">
                    <div class="h-2 bg-primary rounded-t-lg"></div>
                    <div class="p-6">
                        <p class="text-xl text-gray-500">Total Income</p>
                        <p class="text-3xl font-bold text-gray-800">Rp. 200.000</p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="bg-white rounded-lg shadow-4xl w-full">
                    <div class="h-2 bg-primary rounded-t-lg"></div>
                    <div class="p-6">
                        <p class="text-xl text-gray-500">Total Item Sell</p>
                        <p class="text-3xl font-bold text-gray-800">21345612</p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="bg-white rounded-lg shadow-4xl w-full">
                    <div class="h-2 bg-primary rounded-t-lg"></div>
                    <div class="p-6">
                        <p class="text-xl text-gray-500">Total Costumers</p>
                        <p class="text-3xl font-bold text-gray-800">245123</p>
                    </div>
                </div>
            </div>

            <div class="flex md:flex-row md:justify-between w-full">
                <!-- Search Form - 4/12 columns -->
                <form class="flex items-center gap-2 md:w-4/12 mb-4 md:mb-0">
                    <div class="relative w-full">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                            <i class="fa fa-search"></i>
                        </span>
                        <input type="text" placeholder="Find Items"
                            class="border border-gray-300 rounded-2xl pl-10 pr-4 py-3 bg-white w-full focus:outline-none focus:ring-2 focus:ring-primary" />
                    </div>
                </form>

                <!-- Dropdown - 2/12 columns -->
                <div class="md:w-2/12 w-full">
                    <div class="relative w-full">
                        <!-- Dropdown Toggle Button -->
                        <button id="sortingDropdown"
                            class="flex justify-between items-center w-full px-5 py-2.5 bg-white rounded-xl shadow-sm text-left text-lg text-gray-800 cursor-pointer">
                            <span>Sorting By</span>
                            <span
                                class="border-gray-500 border-r-2 border-b-2 p-1 rotate-45 transition-transform duration-200"
                                id="arrow"></span>
                        </button>

                        <!-- Dropdown Menu -->
                        <div id="sortingMenu"
                            class="absolute top-full left-0 w-full mt-1 bg-white rounded-xl shadow-md z-10 hidden overflow-hidden">
                            <div class="dropdown-item py-4 px-5 cursor-pointer text-lg text-gray-800 hover:bg-gray-50">
                                By Year
                            </div>
                            <div
                                class="dropdown-item py-4 px-5 cursor-pointer text-lg text-white bg-orange-500 hover:bg-orange-600">
                                By Month
                            </div>
                            <div class="dropdown-item py-4 px-5 cursor-pointer text-lg text-gray-800">
                                By Weeks
                            </div>
                            <div class="dropdown-item py-4 px-5 cursor-pointer text-lg text-gray-800 hover:bg-gray-50">
                                By Day
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- REPORT TABLE -->
            <div class="bg-white shadow-4xl h-[40em] mt-3 w-full relative rounded-2xl">
                <div class="overflow-y-auto h-full mb-4 rounded-2xl">
                    <table class="table-auto w-full">
                        <thead class="border-b-2 border-tertiary text-white bg-[#747474] h-[3rem] w-full">
                            <tr class="text-center text-sm rounded-lg">
                                <th class="p-6">Action</th>
                                <th class="p-6">Transaction ID</th>
                                <th class="p-6">Date</th>
                                <th class="p-6">Amount</th>
                                <th class="p-6">Orders</th>
                                <th class="p-6">Payment Method</th>
                                <th class="p-6">Types Orders</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr class="border-b border-tertiary h-[3rem] text-center">
                                <td class="p-6">
                                    <span class="material-symbols-outlined status-icon cursor-pointer"
                                        style="color: #4caf50; font-size: 24px">
                                        checklist
                                    </span>
                                </td>
                                <td class="p-6">#00000009</td>
                                <td class="p-6">23/05/2025</td>
                                <td class="p-6">56</td>
                                <td class="p-6">Rp.20.000</td>
                                <td class="p-6">Cash</td>
                                <td class="p-6">
                                    <button>Dine in</button>
                                </td>
                            </tr>
                            <tr class="border-b border-tertiary h-[3rem] text-center">
                                <td class="p-6">
                                    <span class="material-symbols-outlined status-icon cursor-pointer"
                                        style="color: #4caf50; font-size: 24px">
                                        checklist
                                    </span>
                                </td>
                                <td class="p-6">#00000009</td>
                                <td class="p-6">23/05/2025</td>
                                <td class="p-6">56</td>
                                <td class="p-6">Rp.20.000</td>
                                <td class="p-6">Cash</td>
                                <td class="p-6">
                                    <button>Dine in</button>
                                </td>
                            </tr>
                            <tr class="border-b border-tertiary h-[3rem] text-center">
                                <td class="p-6">
                                    <span class="material-symbols-outlined status-icon cursor-pointer"
                                        style="color: #4caf50; font-size: 24px">
                                        checklist
                                    </span>
                                </td>
                                <td class="p-6">#00000009</td>
                                <td class="p-6">23/05/2025</td>
                                <td class="p-6">56</td>
                                <td class="p-6">Rp.20.000</td>
                                <td class="p-6">Cash</td>
                                <td class="p-6">
                                    <button>Dine in</button>
                                </td>
                            </tr>
                            <tr class="border-b border-tertiary h-[3rem] text-center">
                                <td class="p-6">
                                    <span class="material-symbols-outlined status-icon cursor-pointer"
                                        style="color: #4caf50; font-size: 24px">
                                        checklist
                                    </span>
                                </td>
                                <td class="p-6">#00000009</td>
                                <td class="p-6">23/05/2025</td>
                                <td class="p-6">56</td>
                                <td class="p-6">Rp.20.000</td>
                                <td class="p-6">Cash</td>
                                <td class="p-6">
                                    <button>Dine in</button>
                                </td>
                            </tr>
                            <tr class="border-b border-tertiary h-[3rem] text-center">
                                <td class="p-6">
                                    <span class="material-symbols-outlined status-icon cursor-pointer"
                                        style="color: #4caf50; font-size: 24px">
                                        checklist
                                    </span>
                                </td>
                                <td class="p-6">#00000009</td>
                                <td class="p-6">23/05/2025</td>
                                <td class="p-6">56</td>
                                <td class="p-6">Rp.20.000</td>
                                <td class="p-6">Cash</td>
                                <td class="p-6">
                                    <button>Dine in</button>
                                </td>
                            </tr>
                            <tr class="border-b border-tertiary h-[3rem] text-center">
                                <td class="p-6">
                                    <span class="material-symbols-outlined status-icon cursor-pointer"
                                        style="color: #4caf50; font-size: 24px">
                                        checklist
                                    </span>
                                </td>
                                <td class="p-6">#00000009</td>
                                <td class="p-6">23/05/2025</td>
                                <td class="p-6">56</td>
                                <td class="p-6">Rp.20.000</td>
                                <td class="p-6">Cash</td>
                                <td class="p-6">
                                    <button>Dine in</button>
                                </td>
                            </tr>
                            <tr class="border-b border-tertiary h-[3rem] text-center">
                                <td class="p-6">
                                    <span class="material-symbols-outlined status-icon cursor-pointer"
                                        style="color: #4caf50; font-size: 24px">
                                        checklist
                                    </span>
                                </td>
                                <td class="p-6">#00000009</td>
                                <td class="p-6">23/05/2025</td>
                                <td class="p-6">56</td>
                                <td class="p-6">Rp.20.000</td>
                                <td class="p-6">Cash</td>
                                <td class="p-6">
                                    <button>Dine in</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Footer Pagination -->
                <div
                    class="absolute bottom-0 left-0 right-0 flex justify-between items-center p-4 bg-white rounded-b-2xl">
                    <button
                        class="bg-primary text-textColor px-4 py-2 rounded-lg mr-2 flex justify-between items-center hover:opacity-80 transition-all duration-200"
                        onclick="showModal('modalAddItem')">
                        Delete Selected Rows
                        <div class="ml-2 flex items-center">
                            <span class="material-symbols-outlined"> cancel </span>
                        </div>
                    </button>

                    <!-- Pagination -->
                    <div class="flex items-center space-x-2">
                        <span class="text-sm text-gray-500">Page</span>
                        <button
                            class="px-3 py-1 rounded bg-gray-200 text-gray-700 hover:bg-primary hover:text-white transition"
                            aria-label="Previous page">
                            <span class="material-symbols-outlined">chevron_left</span>
                        </button>
                        <button
                            class="px-3 py-1 rounded hover:bg-primary text-textColor hover:text-white font-semibold">
                            1
                        </button>
                        <button
                            class="px-3 py-1 rounded hover:bg-primary text-textColor hover:text-white font-semibold">
                            2
                        </button>
                        <button
                            class="px-3 py-1 rounded hover:bg-primary text-textColor hover:text-white font-semibold">
                            3
                        </button>
                        <button
                            class="px-3 py-1 rounded hover:bg-primary text-textColor hover:text-white font-semibold">
                            4
                        </button>
                        <button
                            class="px-3 py-1 rounded hover:bg-primary text-textColor hover:text-white font-semibold">
                            5
                        </button>

                        <button
                            class="px-3 py-1 rounded bg-gray-200 text-gray-700 hover:bg-primary hover:text-white transition"
                            aria-label="Next page">
                            <span class="material-symbols-outlined">chevron_right</span>
                        </button>
                    </div>
                </div>
            </div>
            <!-- REPORT TABLE END -->

        </section>

        <!-- Modal Edit Item -->
        <div class="fixed inset-0 bg-black/25 backdrop-blur-md justify-center items-center z-50 animate-fadeIn hidden" id="modalAddItem"
            id="modalAddItem">
            <!-- Modal Container -->
            <div
                class="bg-white rounded-lg shadow-lg w-auto h-auto p-6 absolute top-[50%] left-[50%] transform -translate-x-1/2 -translate-y-1/2 scale-95 transition-all duration-300 ease-in-out modal-content">

                <!-- Modal Content -->
                <div class="mt-4 flex flex-col gap-y-2 py-2">
                    <h1 class="text-3xl font-bold text-red-500 mb-2">Delete History</h1>
                    <p class="text-lg text-gray-800">
                        Deleting <span class="font-bold">Transaction ID #000009</span>. This cannot be undone.
                    </p>
                </div>

                <!-- Modal Footer -->
                <div class="mt-6 flex justify-end gap-x-4">
                    <button class="border-2 border-primary text-primary px-4 py-2 rounded"
                        onclick="closeModal('modalAddItem')">
                        Close
                    </button>
                    <button class="bg-primary text-white px-4 py-2 rounded" id="submitBtn">
                        Save Changes
                    </button>
                </div>
            </div>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="/src/js/script.js"></script>
    <script>
    // Get DOM elements
    const dropdown = document.getElementById('sortingDropdown');
    const menu = document.getElementById('sortingMenu');
    const arrow = document.getElementById('arrow');
    const items = document.querySelectorAll('.dropdown-item');

    // Toggle dropdown on click
    dropdown.addEventListener('click', () => {
        menu.classList.toggle('hidden');
        arrow.classList.toggle('-rotate-135');
        arrow.classList.toggle('rotate-45');
    });

    // Close dropdown when clicking outside
    window.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target)) {
            menu.classList.add('hidden');
            arrow.classList.remove('-rotate-135');
            arrow.classList.add('rotate-45');
        }
    });

    // Handle item selection
    items.forEach(item => {
        item.addEventListener('click', () => {
            // Clear all current active states
            items.forEach(i => {
                i.classList.remove('bg-orange-500', 'text-white', 'bg-orange-200');
                i.classList.add('text-gray-800');
                i.classList.add('hover:bg-gray-50');
            });

            // Set this item as active
            item.classList.remove('text-gray-800', 'hover:bg-gray-50');
            item.classList.add('bg-orange-500', 'text-white');
            item.classList.remove('hover:bg-gray-50');
            item.classList.add('hover:bg-orange-600');

            // If there's a next item, set it as light-active
            const nextItem = item.nextElementSibling;
            if (nextItem && nextItem.classList.contains('dropdown-item')) {
                nextItem.classList.remove('text-gray-800', 'hover:bg-gray-50');
                nextItem.setAttribute('style', 'background-color: #FDAE9D');
                nextItem.classList.remove('hover:bg-gray-50');
                nextItem.classList.add('hover:bg-orange-300');
            }

            // Update dropdown text and close menu
            dropdown.querySelector('span').textContent = item.textContent;
            menu.classList.add('hidden');
            arrow.classList.remove('-rotate-135');
            arrow.classList.add('rotate-45');
        });
    });

    function showModal(modalId) {
        const modal = document.getElementById(modalId);
        const modalContent = modal.querySelector(".modal-content");

        modal.classList.remove("hidden");
        setTimeout(() => {
            modalContent.classList.remove("opacity-0", "scale-95");
        }, 10);
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        const modalContent = modal.querySelector(".modal-content");

        modalContent.classList.add("opacity-0", "scale-95");
        setTimeout(() => {
            modal.classList.add("hidden");
        }, 10);
    }

    document.addEventListener('DOMContentLoaded', function() {
        const icon = document.querySelector('.status-icon');
        icon.addEventListener('click', function() {
            if (icon.textContent.trim() === 'checklist') {
                icon.textContent = 'close';
                icon.style.color = '#f44336';
            } else {
                icon.textContent = 'checklist';
                icon.style.color = '#4caf50';
            }
        });
    });
    </script>
</body>

</html><?php /**PATH C:\laragon\www\app_paymin\resources\views/adminpage/orderhistory.blade.php ENDPATH**/ ?>