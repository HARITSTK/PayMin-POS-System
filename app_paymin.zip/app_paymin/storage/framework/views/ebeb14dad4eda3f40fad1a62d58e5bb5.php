<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="assets/FEproject/src/output.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/FEproject/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/FEproject/src/components/items.css" />

    <!-- Google Icons -->

    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0"
    />
  </head>
  <body>
    <main
      class="flex items-center justify-between h-screen bg-[#E6EEFD] overflow-hidden font-poppins"
    >
      <nav
        id="navbar"
        class="bg-white h-full overflow-hidden w-[7.2rem] min-w-[7.2rem] p-5 shadow-4xl rounded-r-4xl"
      >
        <div class="flex items-center justify-center mb-2">
          <img
            src="assets/logoMin.png"
            alt="Logo"
            class="w-20 h-w-20 rounded-full"
          />
        </div>
        <ul id="navbar-list" class="flex flex-col h-full w-full relative z-10">
          <!-- Daftar item navigasi utama -->
          <li
            class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-primary transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer"
          >
            <a
              href="/src/pages/home.html"
              class="flex flex-col items-center justify-center"
              onclick="route()"
            >
              <i class="fa fa-home fa-2x"></i>

              <p class="text-sm">Home</p>
            </a>
          </li>
          <li
            class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-primary transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer"
          >
            <a
              href="/src/pages/order.html"
              class="flex flex-col items-center justify-center"
              onclick="route()"
            >
              <i class="fa fa-cart-plus fa-2x"></i>
              <p class="text-sm">Orders</p>
            </a>
          </li>
          <li
            class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-primary transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer"
          >
            <a
              href="/src/pages/report.html"
              class="flex flex-col items-center justify-center"
              onclick="route()"
            >
              <i class="fa fa-file-text-o fa-2x"></i>
              <p class="text-sm">Report</p>
            </a>
          </li>
          <li
            class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-primary transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer"
          >
            <a
              href="/src/pages/items.html"
              class="flex flex-col items-center justify-center"
              onclick="route()"
            >
              <i class="fa fa-th fa-2x"></i>
              <p class="text-sm">Items</p>
            </a>
          </li>
          <li
            class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-primary transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer"
          >
            <a
              href="/src/pages/master.html"
              class="flex flex-col items-center justify-center"
              onclick="route()"
            >
              <i class="fa fa-key fa-2x"></i>
              <p class="text-sm">Master</p>
            </a>
          </li>
          <li
            class="flex flex-col items-center justify-center text-[#8B8B8B] hover:text-primary transition-all duration-300 ease-in-out h-[70px] relative z-20 cursor-pointer"
          >
            <a
              href="/src/pages/settings.html"
              class="flex flex-col items-center justify-center"
              onclick="route()"
            >
              <i class="fa fa-cog fa-2x"></i>
              <p class="text-sm">Settings</p>
            </a>
          </li>
          <span class="highlight-span mx-auto shadow-2xl"></span>
          <li
            class="flex flex-col items-center justify-center mt-[4em] text-[#8B8B8B] hover:text-red-400 cursor-pointer"
          >
            <i class="fa fa-sign-out fa-2x"></i>
            <p class="text-sm">Logout</p>
          </li>
        </ul>
      </nav>
      <!-- Main Content -->
      <section class="h-full w-full p-11 box-border overflow-y-auto">
        <div class="">
          <h1 class="text-[30pt] font-bold text-[#353535]">Items Management</h1>
        </div>
        <div class="flex gap-4 py-6 w-full">
          <!-- Card 1 -->
          <div class="bg-white rounded-lg shadow-4xl w-full">
            <div class="h-2 bg-primary rounded-t-lg"></div>
            <div class="p-6">
              <p class="text-xs text-gray-500">Out of Stock</p>
              <p class="text-3xl font-bold text-gray-800">18 Items</p>
            </div>
          </div>

          <!-- Card 2 -->
          <div class="bg-white rounded-lg shadow-4xl w-full">
            <div class="h-2 bg-primary rounded-t-lg"></div>
            <div class="p-6">
              <p class="text-xs text-gray-500">Low Stock</p>
              <p class="text-3xl font-bold text-gray-800">2 Items</p>
            </div>
          </div>

          <!-- Card 3 -->
          <div class="bg-white rounded-lg shadow-4xl w-full">
            <div class="h-2 bg-primary rounded-t-lg"></div>
            <div class="p-6">
              <p class="text-xs text-gray-500">Total Items</p>
              <p class="text-3xl font-bold text-gray-800">245 Items</p>
            </div>
          </div>
        </div>

        <div
          class="bg-white p-8 shadow-4xl h-[40em] w-full relative rounded-lg"
        >
          <!-- Items Sorting -->
          <div
            class="flex justify-between w-full h-auto border-gray-600 bg-white border-b-[1px] p-2"
          >
            <ul class="flex flex-row items-center gap-3">
              <li
                class="border-2 border-gray-400 rounded-3xl px-5 hover:text-primary hover:border-primary cursor-pointer hover:bg-[#FFB09F]"
              >
                <button
                  type="button"
                  class="w-full h-full focus:outline-none cursor-pointer"
                >
                  All
                </button>
              </li>
              <li
                class="border-2 border-gray-400 rounded-3xl px-5 hover:text-primary hover:border-primary cursor-pointer hover:bg-[#FFB09F]"
              >
                <button
                  type="button"
                  class="w-full h-full focus:outline-none cursor-pointer"
                >
                  Cake
                </button>
              </li>
              <li
                class="border-2 border-gray-400 rounded-3xl px-5 hover:text-primary hover:border-primary cursor-pointer hover:bg-[#FFB09F]"
              >
                <button
                  type="button"
                  class="w-full h-full focus:outline-none cursor-pointer"
                >
                  Drink
                </button>
              </li>
              <li
                class="border-2 border-gray-400 rounded-3xl px-5 hover:text-primary hover:border-primary cursor-pointer hover:bg-[#FFB09F]"
              >
                <button
                  type="button"
                  class="w-full h-full focus:outline-none cursor-pointer"
                >
                  Food
                </button>
              </li>
            </ul>

            <form class="flex items-center gap-2">
              <div class="relative w-full">
                <span
                  class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400"
                >
                  <i class="fa fa-search"></i>
                </span>
                <input
                  type="text"
                  placeholder="Find Items"
                  class="border border-gray-300 rounded-2xl pl-10 pr-4 py-2 w-full focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </form>
          </div>

          <!-- Items List -->
          <div class="w-full h-[33em] overflow-y-auto p-4">
            <div
              class="grid grid-cols-4 lg:grid-cols-4 auto-rows-auto gap-10 justify-items-center"
              id="orderList"
            >
              <!-- Add Item Card -->
              <div
                class="flex flex-col items-center justify-center border-2 border-dashed border-primary rounded-xl cursor-pointer hover:bg-[#FFB09F] transition-all duration-200 p-6 w-full h-[50vh]"
              >
                <button
                  class="flex flex-col items-center justify-center focus:outline-none"
                  onclick="showModal('modalAddItem')"
                >
                  <span
                    class="flex items-center justify-center w-16 h-16 text-primary rounded-full mb-3"
                  >
                    <span
                      class="material-symbols-outlined"
                      style="font-size: 5rem"
                      >add</span
                    >
                  </span>
                  <span class="text-primary font-semibold">Add New Item</span>
                </button>
              </div>

              <!-- Item Card Template (Repeated) -->
              <div
                class="w-full h-full bg-white rounded-lg shadow-4xl card-container"
              >
                <div class="flex flex-col items-center w-full h-full">
                  <!-- Gambar produk -->
                  <img
                    src="/assets/coffee.png"
                    alt="Product"
                    class="w-44 object-cover rounded-full border-4 border-white shadow"
                  />

                  <div
                    class="flex flex-col items-center justify-center w-full mt-auto"
                  >
                    <!-- Nama produk -->
                    <h2 class="font-semibold text-center text-gray-800 text-lg">
                      Coffe Capuchino
                    </h2>

                    <!-- Harga dan stok -->
                    <p class="text-[11pt] text-gray-500 mt-1">
                      Rp.20.000 <span class="mx-1">|</span> 20 Stock
                    </p>
                  </div>

                  <!-- Tombol -->
                  <div
                    class="w-full flex justify-between items-center mt-auto h-16"
                  >
                    <button
                      class="bg-primary h-full text-white text-lg w-full rounded-bl-lg"
                      onclick="showModal('modalEditItem')"
                    >
                      Edit menu
                    </button>
                    <button
                      class="text-gray-500 bg-tertiary hover:text-gray-700 w-[40%] h-full rounded-br-lg"
                      onclick="showModal('modalDeleteItem')"
                    >
                      <div
                        class="w-full h-full transition-all duration-200 flex items-center justify-center text-white text-lg"
                      >
                        <span class="material-symbols-outlined"> delete </span>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Delete Items Modal -->
      <div
        class="fixed inset-0 backdrop-blur-md bg-opacity-50 flex justify-center items-center z-50 animate-fadeIn hidden"
        id="modalDeleteItem"
      >
        <!-- Modal Container -->
        <div
          class="bg-white rounded-2xl p-6 w-[300px] shadow-lg text-center modal-content"
        >
          <h2 class="text-lg font-semibold text-red-500 mb-4">Delete Items</h2>

          <img
            src="/dist/coffee.png"
            alt="Coffee"
            class="w-24 h-24 mx-auto mb-4 rounded-full object-cover"
          />

          <h3 class="text-lg font-semibold text-gray-800">Coffe Capuchino</h3>
          <p class="text-sm text-gray-600">Rp 20.000 | 20 Stock</p>

          <p class="text-xs text-gray-500 mt-4">
            Deleting items will remove all of information<br />
            from our database. This cannot be undone.
          </p>

          <div class="flex justify-between mt-6 space-x-4">
            <button
              class="flex-1 border border-red-500 text-red-500 rounded-xl py-2 hover:bg-red-100 transition"
              onclick="closeModal('modalDeleteItem')"
            >
              Cancel
            </button>
            <button
              class="flex-1 bg-primary text-white rounded-xl py-2 hover:opacity-90 transition"
              onclick="deleteCard('.card-container')"
            >
              Delete
            </button>
          </div>
        </div>
      </div>

      <!-- Modal Edit Item -->
      <div
        class="fixed inset-0 backdrop-blur-md bg-opacity-50 justify-center items-center z-50 animate-fadeIn hidden"
        id="modalEditItem"
      >
        <!-- Modal Container -->
        <div
          class="bg-white rounded-lg shadow-lg w-auto h-auto p-6 absolute top-[50%] left-[50%] transform -translate-x-1/2 -translate-y-1/2 scale-95 transition-all duration-300 ease-in-out modal-content"
        >
          <!-- Modal Header -->
          <div class="flex flex-col w-full">
            <h2 class="text-xl font-semibold">Edit item</h2>
            <p>Change item</p>
          </div>

          <!-- Modal Content -->
          <div class="mt-4 flex justify-between gap-x-4 py-2">
            <!-- drag and drop image -->
            <div
              class="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg w-[15vw] h-auto cursor-pointer hover:bg-gray-100 transition-all duration-200 p-3"
              id="imageView"
            >
              <i class="fa fa-cloud-upload fa-3x text-gray-400"></i>
              <p class="text-gray-500 mt-2 text-center">
                Drag and drop your image here
              </p>
              <input
                type="file"
                accept="image/*"
                class="hidden"
                id="fileInput"
              />
              <label
                for="fileInput"
                class="mt-2 bg-primary text-white px-4 py-2 rounded cursor-pointer"
                >Choose File</label
              >
            </div>

            <!-- Input fields -->
            <div class="mt-4">
              <label
                for="itemName"
                class="block text-sm font-medium text-gray-700"
                >Item Name</label
              >
              <input
                type="text"
                id="itemName"
                class="mt-1 p-1 block w-[23vw] border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
              />

              <label
                for="itemStock"
                class="block text-sm font-medium text-gray-700 mt-4"
                >Item Stock</label
              >
              <input
                type="number"
                id="itemStock"
                class="mt-1 p-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
              />

              <label
                for="itemPrice"
                class="block text-sm font-medium text-gray-700 mt-4"
                >Item Price</label
              >
              <input
                type="number"
                id="itemPrice"
                class="mt-1 p-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
              />
            </div>
          </div>

          <!-- Modal Footer -->
          <div class="mt-6 flex justify-end gap-x-4">
            <button
              class="border-2 border-primary text-primary px-4 py-2 rounded"
              onclick="closeModal('modalEditItem')"
            >
              Close
            </button>
            <button
              class="bg-primary text-white px-4 py-2 rounded"
              id="submitBtn"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </main>

    <script src="assets/FEproject/src/js/items.js"></script>
  </body>
</html>
<?php /**PATH C:\laragon\www\app_paymin\resources\views/adminpage/items.blade.php ENDPATH**/ ?>